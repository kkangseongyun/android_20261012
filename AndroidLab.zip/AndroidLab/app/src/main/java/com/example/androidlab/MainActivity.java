package com.example.androidlab;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.androidlab.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

//    Button button;
//    EditText editView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //액티비티 영역이 시스템 영역까지 차지하라..
        //status bar, navigation bar (시스템 영역)
        EdgeToEdge.enable(this);

        //화면 출력 명령..
        //layout xml 에 명시된대로 객체를 생성해서 뷰 객체가 메모리에 올라왔고(inflate), 메모리 내용대로 출력
//        setContentView(R.layout.activity_main);
//        //생성된 뷰 객체 중, 코드에서 이용하고자 하는 객체 획득..
//        button = findViewById(R.id.button);
//        editView = findViewById(R.id.editView);
//        //이벤트 등록..
//        button.setOnClickListener(view -> {
//            String data = editView.getText().toString();
//            Log.d("TAG", data);
//        });

        //ViewBinding 이용 코드.......................
        //ViewBinding 에게 일은 시켜야 한다. inflate
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        //화면 출력..
        setContentView(binding.getRoot());

        binding.button.setOnClickListener(view -> {
            String data = binding.editView.getText().toString();
            Log.d("TAG", data);
        });


        //시스템 컨텐츠에 앱의 내용이 겹치지 않게 여백 설정..
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}