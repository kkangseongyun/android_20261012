plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.androidlab"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.androidlab"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    //아래의 선언만으로.. layout xml 에 해당되는 XXXBinging 클래스 자동 만들어진다.
    viewBinding.enable = true
}

dependencies {
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)



}