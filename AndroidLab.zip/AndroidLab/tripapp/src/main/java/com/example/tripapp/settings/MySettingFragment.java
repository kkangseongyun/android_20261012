package com.example.tripapp.settings;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.EditTextPreference;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import com.example.tripapp.R;

//설정 xml 을 등록할 Fragment
//Fragment : custom view ==> activity 가 출력해야 한다.
public class MySettingFragment extends PreferenceFragmentCompat {
    @Override
    public void onCreatePreferences(@Nullable Bundle savedInstanceState, @Nullable String rootKey) {
        //필수..
        //설정 xml 등록 : 화면 제공, 설정 내용 저장까지 자동..
        setPreferencesFromResource(R.xml.settings, rootKey);

        //필요하다면..
        //key 를 이용해서 설정 객체 획득이 가능하다..
        EditTextPreference idPreference = findPreference("id");
        ListPreference colorPreference = findPreference("color");

        //summary 동적 지정..
        //case1 : 설정 값을 그대로 summary 에...
        colorPreference.setSummaryProvider(ListPreference.SimpleSummaryProvider.getInstance());
        //case2 : 개발자 알고리즘으로 summary 지정..
        idPreference.setSummaryProvider(new Preference.SummaryProvider<EditTextPreference>() {
            @Nullable
            @Override
            public CharSequence provideSummary(@NonNull EditTextPreference preference) {
                //현재 설정 값 획득..
                String text = preference.getText();
                if(TextUtils.isEmpty(text)){
                    return "설정이 되지 않았습니다.";
                }else {
                    return "설정된 ID 는 "+ text + " 입니다.";
                }
            }
        });

        //설정 값이 저장은 자동으로 되지만.. 설정값이 변경되는 순간의 추가 이벤트 처리가 있다면..
        idPreference.setOnPreferenceChangeListener((preference, newValue) -> {
            Log.d("TAG", "key : "+ preference.getKey() + ", newValue : "+ newValue);
            return true;
        });
    }
}












