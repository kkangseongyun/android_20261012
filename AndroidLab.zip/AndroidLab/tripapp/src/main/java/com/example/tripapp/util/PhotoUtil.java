package com.example.tripapp.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;
import android.widget.ImageView;

import java.io.InputStream;

public class PhotoUtil {
    //gallery app 연동, 사진 선택 -> 선택된 사진 uri 전달된다.
    public static boolean uriToImageView(Context context, Uri uri, ImageView imageView){

        Log.d("kkang", "${uri.toString()}");
        //gallery에 있는 사진을 읽고자 한다.  OOM 문제 고려해야 한다.
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inSampleSize = 10;//10분의 1로 데이터 사이즈 줄여서 로딩
        try {
            //gallery provider에게 구체적인 데이터(경로 문자열 등)을 획득할 수도 있지만..
            //선택한 이미지를 읽는 작업, 그 작업을 하는 Stream 도 제공
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, option);
            inputStream.close();
            if(bitmap != null) {
                //Bitmap : 이미지 데이터 타입..
                //이미지 출력..
                imageView.setImageBitmap(bitmap);
                return true;
            }else {
                return  false;
            }
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }

    }

    //camera...
    public static boolean fileToImageView(Context context, String filePath, ImageView imageView){
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inSampleSize = 10;

        Bitmap bitmap = BitmapFactory.decodeFile(filePath, option);
        if(bitmap != null) {
            imageView.setImageBitmap(bitmap);
            return true;

        }
        return false;
    }
}
