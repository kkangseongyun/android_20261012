package com.example.tripapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.tripapp.databinding.ActivityDetailBinding;
import com.example.tripapp.detail.DetailMainFragment;
import com.example.tripapp.detail.DetailNewsFragment;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity {

    //ViewPager의 항목을 만들어주는 Adapter
    class MyPagerAdapter extends FragmentStateAdapter {
        List<Fragment> fragments;
        public MyPagerAdapter(FragmentActivity activity){
            super(activity);
            fragments = new ArrayList<>();
            fragments.add(new DetailMainFragment());
            fragments.add(new DetailNewsFragment());
        }
        //항목 갯수를 판단하기 위해서 자동 호출..
        @Override
        public int getItemCount() {
            return fragments.size();
        }
        //항목 갯수 만큼 반복 호출..
        //각 항목의 Fragment를 결정하기 위해서 자동 호출..
        @NonNull
        @Override
        public Fragment createFragment(int position) {
            return fragments.get(position);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        ActivityDetailBinding binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        MyPagerAdapter adapter = new MyPagerAdapter(this);
        binding.viewpager.setAdapter(adapter);
    }
}