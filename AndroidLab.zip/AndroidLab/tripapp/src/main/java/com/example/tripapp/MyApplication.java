package com.example.tripapp;

import android.app.Application;

import com.example.tripapp.network.NetworkService;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

//안드로이드 Applicaiton 클래스
//앱에서 하나만 만들 수 있다..
//manifest에 등록해야 한다..
//앱의 프로세스가 구동되면서 최초에 가장 먼저 하나만 생성,
//앱의 생명주기와 동일하게 유지.
public class MyApplication extends Application {

    //앱이 실행되면서 앱 전역에서 사용되는 최초에 한번만 초기화 하면 되는 코드..
    //앱 전역에서 사용하는 상수변수..
    public String API_KEY = "079dac74a5f94ebdb990ecf61c8854b7";
    public NetworkService networkService;

    public MyApplication(){
        Retrofit.Builder builder = new Retrofit.Builder();
        builder.baseUrl("https://newsapi.org");
        builder.addConverterFactory(GsonConverterFactory.create());
        networkService = builder.build().create(NetworkService.class);
    }
}
