package com.example.tripapp;

import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class MyJobService extends JobService {

    @Override
    public boolean onStartJob(JobParameters params) {
        Log.d("TAG", "MyJobService...");
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}