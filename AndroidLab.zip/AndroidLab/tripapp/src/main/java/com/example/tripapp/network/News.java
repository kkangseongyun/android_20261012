package com.example.tripapp.network;

//뉴스 데이터 추상화 DTO
public class News {
    long id;
    String author;
    String title;
    String description;
    String urlToImage;
    String publishedAt;
}
