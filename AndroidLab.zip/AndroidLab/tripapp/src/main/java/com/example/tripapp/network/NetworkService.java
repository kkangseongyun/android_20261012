package com.example.tripapp.network;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

//네트워킹시 호출할 함수 선언..
//retrofit에 등록..
public interface NetworkService {
    @GET("/v2/everything")
    public Call<Page> getList(
            @Query("q") String q,
            @Query("apiKey") String apiKey,
            @Query("page") long page,
            @Query("pageSize") int pageSize
    );

    @GET
    Call<ResponseBody> getNetworkImage(@Url String url);
}
