package com.example.tripapp.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//앱의 데이터베이스 관리적인 코드 추상화...
public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context){
        super(context, "testdb", null, 1);
    }
    //앱 인스톨 후 최초 한번.. 주로 테이블 생성..
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table TB_INFO (" +
                "_id integer primary key autoincrement," +
                "email not null," +
                "phone," +
                "photo)");
    }
    //db version 변경시마다...
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
