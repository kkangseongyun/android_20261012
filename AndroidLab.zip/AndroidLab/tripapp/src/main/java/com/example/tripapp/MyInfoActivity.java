package com.example.tripapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tripapp.databinding.ActivityMyInfoBinding;
import com.example.tripapp.db.DBUtil;

public class MyInfoActivity extends AppCompatActivity {

    ActivityMyInfoBinding binding;

    String email;
    String phone;
    String photo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMyInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //액티비티 실행되자마자.. db select, 화면 출력..
        Cursor cursor = DBUtil.selectInfo(this);
        if(cursor != null){
            //row 선택..
            if(cursor.moveToFirst()){
                email = cursor.getString(1);
                phone = cursor.getString(2);
                photo = cursor.getString(3);

                binding.myInfoEmail.setText(email);
                binding.myInfoPhone.setText(phone);
            }
        }

        binding.testSaveButton.setOnClickListener(view -> {
            email = binding.myInfoEmail.getText().toString();
            phone = binding.myInfoPhone.getText().toString();

            if(email != null && !email.isEmpty()){
                if(DBUtil.insertInfo(this, email, phone, photo)){
                    //화면을 이전 화면으로 자동 이동..
                    finish();
                }
            }else {
                Toast.makeText(this, "email 입력은 필수입니다.", Toast.LENGTH_SHORT)
                        .show();
            }
        });
    }
}