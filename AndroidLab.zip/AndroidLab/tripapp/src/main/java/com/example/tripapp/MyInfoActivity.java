package com.example.tripapp;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tripapp.databinding.ActivityMyInfoBinding;
import com.example.tripapp.db.DBUtil;
import com.example.tripapp.util.PhotoUtil;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MyInfoActivity extends AppCompatActivity {

    ActivityMyInfoBinding binding;

    String email;
    String phone;
    String photo;

    //외장 앱별에 만들 파일 경로, 카메라 앱에게 전달할 파일 경로..
    String cameraFilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMyInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //액티비티 실행되자마자.. db select, 화면 출력..
        Cursor cursor = DBUtil.selectInfo(this);
        if(cursor != null){
            //row 선택..
            if(cursor.moveToFirst()){
                email = cursor.getString(1);
                phone = cursor.getString(2);
                photo = cursor.getString(3);

                binding.myInfoEmail.setText(email);
                binding.myInfoPhone.setText(phone);

                if(photo != null && !photo.isEmpty()){
                    PhotoUtil.uriToImageView(this, Uri.parse(photo), binding.userImageView);
                }
            }
        }

        binding.testSaveButton.setOnClickListener(view -> {
            email = binding.myInfoEmail.getText().toString();
            phone = binding.myInfoPhone.getText().toString();

            if(email != null && !email.isEmpty()){
                if(DBUtil.insertInfo(this, email, phone, photo)){
                    //이전 화면으로 되돌리면서.. 데이터 포함..
                    //자신을 실행시켰던 인텐트 객체 획득..
                    Intent intent = getIntent();
                    intent.putExtra("phone", phone);
                    intent.putExtra("email", email);
                    intent.putExtra("photo", photo);
                    //어떤 상태로 화면을 되돌린 것이다. 상태 표현..
                    setResult(RESULT_OK, intent);
                    //화면을 이전 화면으로 자동 이동..
                    finish();
                }
            }else {
                Toast.makeText(this, "email 입력은 필수입니다.", Toast.LENGTH_SHORT)
                        .show();
            }
        });


        ActivityResultLauncher<String[]> imagePickerLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.OpenDocument(),
                        uri -> {
                            if (uri != null) {
                                getContentResolver().takePersistableUriPermission(
                                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                photo = uri.toString();

                                PhotoUtil.uriToImageView(this, uri, binding.userImageView);
                            }
                        }
                );

        binding.galleryButton.setOnClickListener(view -> {

            imagePickerLauncher.launch(new String[]{"image/*"});

        });

        ActivityResultLauncher<Intent> requestCameraFileLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    // 카메라 앱
                    PhotoUtil.fileToImageView(this, cameraFilePath, binding.userImageView);
                    photo = cameraFilePath;

                });
        binding.cameraButton.setOnClickListener(view -> {
            // 카메라 앱
            // 파일 준비
            String timeStamp =
                    new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            try {
                File storageDir =
                        getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                File file = File.createTempFile(
                        "JPEG_${timeStamp}_",
                        ".jpg",
                        storageDir
                );
                cameraFilePath = file.getAbsolutePath();
                Uri photoURI = FileProvider.getUriForFile(
                        this,
                        "com.example.tripapp.fileprovider", file
                );
                //카메라앱 실행..
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //아래의 extra 정보가 있으면 파일 공유, 없으면 썸네일 방법으로 동작한다.
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                requestCameraFileLauncher.launch(intent);
            }catch (Exception e){
                e.printStackTrace();
            }

        });

    }
}