package com.example.tripapp.network;

import java.util.ArrayList;

//서버 데이터 DTO
public class Page {
    public ArrayList<News> articles;
}
