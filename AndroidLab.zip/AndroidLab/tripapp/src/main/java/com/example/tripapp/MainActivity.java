package com.example.tripapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tripapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    long initTime;//back button 이 눌린 시간..

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Toolbar 가 개발자 뷰이다.. 어느 뷰인지는 알려줘야 한다.
        setSupportActionBar(binding.toolbar);

        //delegation event...
        binding.mainEvent.setOnClickListener(view -> {
            Intent intent = new Intent(this, DetailActivity.class);
            startActivity(intent);
        });

        binding.testAbout.setOnClickListener(view -> {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
        });

        binding.testMyInfo.setOnClickListener(view -> {
            Intent intent = new Intent(this, MyInfoActivity.class);
            startActivity(intent);
        });

//        binding.testSetting.setOnClickListener(view -> {
//            Intent intent = new Intent(this, SettingActivity.class);
//            startActivity(intent);
//        });

        //back button 이벤트 처리..
        //기본은 키 취급이 되어 onKeyDown() 오버라이드 받아서 처리...
        //api 33 버전에서 onKeyDown() 으로 back button 이벤트 처리는 deprecated 되었고..
        //api 36 에서 onKeyDown() 으로 back button 이벤트 처리는 더이상 지원하지 않는다..
        //callbcak 등록 방식으로..
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if(System.currentTimeMillis() - initTime > 3000){
                    Toast.makeText(MainActivity.this, "종료하려면 한번 더 누르세요.", Toast.LENGTH_SHORT)
                            .show();
                    initTime = System.currentTimeMillis();
                }else {
                    //앱 종료시킨다.
                    finish();
                }
            }
        });

    }

    //메뉴 구성하기 위해서 자동 호출..
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //위 코드만으로.. 메뉴는 출력된다.
        //SearchView 가 포함된 MenuItem 객체 획득하고 그 MenuItem 에 포함된 SearchView 객체 획득..
        MenuItem menuItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            //최종 검색을 위해서 키보드의 검색 버튼을 누른 순간..
            @Override
            public boolean onQueryTextSubmit(String query) {
                Toast.makeText(MainActivity.this, query, Toast.LENGTH_SHORT).show();
                searchView.setQuery("", false);//검색어 지우기
                searchView.setIconified(true);//다시 아이콘으로 복귀..
                return false;
            }
            //검색어 입력시마다.. 매개변수가 그 순간 입력된 검색어..
            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
    //메뉴 이벤트 처리...
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.setting){
            Intent intent = new Intent(this, SettingActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}