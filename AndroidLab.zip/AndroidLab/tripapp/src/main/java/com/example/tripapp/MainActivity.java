package com.example.tripapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tripapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    long initTime;//back button 이 눌린 시간..

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //delegation event...
        binding.mainEvent.setOnClickListener(view -> {
            Intent intent = new Intent(this, DetailActivity.class);
            startActivity(intent);
        });

        binding.testAbout.setOnClickListener(view -> {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
        });

        //back button 이벤트 처리..
        //기본은 키 취급이 되어 onKeyDown() 오버라이드 받아서 처리...
        //api 33 버전에서 onKeyDown() 으로 back button 이벤트 처리는 deprecated 되었고..
        //api 36 에서 onKeyDown() 으로 back button 이벤트 처리는 더이상 지원하지 않는다..
        //callbcak 등록 방식으로..
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if(System.currentTimeMillis() - initTime > 3000){
                    Toast.makeText(MainActivity.this, "종료하려면 한번 더 누르세요.", Toast.LENGTH_SHORT)
                            .show();
                    initTime = System.currentTimeMillis();
                }else {
                    //앱 종료시킨다.
                    finish();
                }
            }
        });

    }
}