package com.example.tripapp.detail;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.tripapp.databinding.FragmentDetailMainBinding;

public class DetailMainFragment extends Fragment {
    //Fragment에 의해 출력될 화면을 결정하기 위해서 자동 호출..
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return FragmentDetailMainBinding.inflate(inflater, container, false).getRoot();
    }
}
