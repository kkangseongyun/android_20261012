package com.example.tripapp.detail;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tripapp.R;
import com.example.tripapp.databinding.FragmentDetailMainBinding;
import com.example.tripapp.databinding.ItemRecyclerviewBinding;

import java.lang.reflect.Array;
import java.util.ArrayList;


//데이터 VO
class Product {
    int photo;
    String title;
    String desc;

    public Product(int photo, String title, String desc){
        this.photo = photo;
        this.title = title;
        this.desc = desc;
    }
}

//항목을 구성하기 위한 뷰를 가지는 역할자..
//RecyclerView 내부에서 항목별 재사용
class MyViewHolder extends RecyclerView.ViewHolder {
    ItemRecyclerviewBinding binding;

    public MyViewHolder(ItemRecyclerviewBinding binding){
        super(binding.getRoot());
        this.binding = binding;
    }
}

//ViewHolder를 이용해 각 항목을 구성하는 역할자..
class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
    ArrayList<Product> datas;//항목 구성 데이터..

    public MyAdapter(ArrayList<Product> datas){
        this.datas =datas;
    }
    //항목 갯수 판단..
    @Override
    public int getItemCount() {
        return datas.size();
    }
    //항목 구성을 위한 ViewHolder를 결정하기 위해서 자동 호출..
    //한 화면에 같이 나올 정도의 갯수로만 호출해서 객체를 유지, 나머지는 자동으로 재사용..
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(ItemRecyclerviewBinding.inflate(LayoutInflater.from(
                parent.getContext()
        ), parent, false));
    }
    //각각의 항목을 구성하기 위해서 호출..
    //position : 항목 index
    //holder : onCreateViewHolder 에서 리턴시킨 객체..
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Product product = datas.get(position);

        holder.binding.itemImageView.setImageResource(product.photo);
        holder.binding.itemTitleView.setText(product.title);
        holder.binding.itemDescView.setText(product.desc);
    }
}

class MyDecoration extends RecyclerView.ItemDecoration {
    //각 항목을 꾸미기 위해서 자동 호출..
    //outRect : 각 항목이 화면에 나오는 사각형 정보..
    @Override
    public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);
        //몇번째 항목을 꾸미기 위해서 호출이 된것인지, index 획득..
        int index = parent.getChildAdapterPosition(view) + 1;
        if(index % 3 == 0)
            outRect.set(10, 10, 10, 60);
        else
            outRect.set(10, 10, 10, 0);
    }
}

public class DetailMainFragment extends Fragment {
    //Fragment에 의해 출력될 화면을 결정하기 위해서 자동 호출..
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FragmentDetailMainBinding binding = FragmentDetailMainBinding.inflate(inflater, container, false);

        ArrayList<Product> datas = new ArrayList<>();

        datas.add(new Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"));
        datas.add(new Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"));
        datas.add(new Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"));
        datas.add(new Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"));
        datas.add(new Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"));
        datas.add(new Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"));
        datas.add(new Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"));
        datas.add(new Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"));
        datas.add(new Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"));
        datas.add(new Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"));
        datas.add(new Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"));
        datas.add(new Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"));
        datas.add(new Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"));
        datas.add(new Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"));
        datas.add(new Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"));

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.recyclerView.setAdapter(new MyAdapter(datas));
        binding.recyclerView.addItemDecoration(new MyDecoration());

        return binding.getRoot();
    }
}
