package com.example.tripapp.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DBUtil {
    public static boolean insertInfo(Context context, String email, String phone, String photo){
        try {
            SQLiteDatabase db = new DBHelper(context).getWritableDatabase();
            db.execSQL("insert into TB_INFO (email, phone, photo) values (?,?,?)",
                    new String[]{email, phone, photo});
            db.close();
            return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public static Cursor selectInfo(Context context){
        try {
            SQLiteDatabase db = new DBHelper(context).getReadableDatabase();
            Cursor cursor = db.rawQuery("select * from TB_INFO order by _id DESC limit 1", null);
            return cursor;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
