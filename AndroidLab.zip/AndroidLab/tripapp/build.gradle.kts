plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.tripapp"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.tripapp"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    viewBinding.enable = true
}

dependencies {
    //하나의 프로젝트내에 여러 모듈이 있다.
    //여러 모듈에서 공통으로 이용하는 라이브러리가 있다.
    //그 라이브러리 버전 변경이 되면.. 직접 모듈의 build.gradle.kts 에 등록했다면 여러곳을 수정해야 한다..
    //버전 관리의 불편함을 해결하기 위해서.. 라이브러리를 libs.versions.toml 에 등록하고..
    //각 모듈에서는 링크만 걸어서 이용..
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
//    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation(libs.constraintlayout)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)

    //라이브러리 등록, 다운로드, 빌드시 적용..
    //sync now 하는 순간 다운로드..
    //androidx 라이브러리는 많은 경우 aaa 라이브러리가 있다면 aaa-ktx 라이브러리도 제공한다.
    //동일 라이브러리, aaa(자바로 만든),  aaa-ktx(코틀린으로 만든 - 코틀린 개발자의 편의성을 위해서..)

    //group-id:artifact-id:version
    implementation("androidx.preference:preference:1.2.1")
    implementation("com.google.code.gson:gson:2.10.1")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
}













